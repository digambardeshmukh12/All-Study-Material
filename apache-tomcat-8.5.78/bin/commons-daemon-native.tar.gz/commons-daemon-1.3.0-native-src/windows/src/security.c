/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "apxwin.h"
#include "private.h"
#include <stdio.h>
#include <accctrl.h>
#include <aclapi.h>

DWORD
apxSecurityGrantFileAccessToUser(
    LPCWSTR szPath,
    LPCWSTR szUser)
{
    WCHAR sPath[SIZ_PATHLEN];
    WCHAR sUser[SIZ_RESLEN];
    DWORD dwResult;
    PACL pOldDACL;
    PACL pNewDACL;
    PSECURITY_DESCRIPTOR pSD;
    EXPLICIT_ACCESS ea;

    lstrlcpyW(sPath, SIZ_PATHLEN, szPath);

    if (szUser) {
        /* The API used to set file permissions doesn't always recognised the
         * same users as the API used to configured services. We do any
         * necessary conversion here. The known issues are:
         * LocalSystem is not recognised. It needs to be converted to
         * "NT Authority\System"
         * User names for the local machine that use the ".\username" form need
         * to have the leading ".\" removed.
         */
        if (!StrCmpW(STAT_SYSTEM, szUser)) {
            lstrlcpyW(sUser, SIZ_RESLEN, STAT_SYSTEM_WITH_DOMAIN);
        } else {
            if (StrStrW(szUser, L".\\") == szUser) {
                szUser +=2;
            }
            lstrlcpyW(sUser, SIZ_RESLEN, szUser);
        }
    } else {
        lstrlcpyW(sUser, SIZ_RESLEN, DEFAULT_SERVICE_USER);
    }
    
    /* Old (current) ACL. */
    dwResult = GetNamedSecurityInfoW(
            sPath,
            SE_FILE_OBJECT,
            DACL_SECURITY_INFORMATION,
            NULL,
            NULL,
            &pOldDACL,
            NULL,
            &pSD);
    if (dwResult) {
        return dwResult;
    }

    /* Additional access. */
    ZeroMemory(& L,
      "e API Wait(APa_AT_S:w/
    Zero*/
T
     STAM l = 0;
    LP   Cl except in compliaB   Len  }
c     STAM l = 0u   "e API Wait(APa_AT_S:w/
    Zero*/
T    &lpProait(APaCl ub lstrlcpyW(sUser, SIZ_RESLEN, STAT_SYSTEM  STAM l =oResult;
otrlcpyW(sUser, SIZ_RESLEN,)_RESLEN, DEFA   DYNLOAD_FPTR_DECLARE(Exit    }

    if (EN, STAT_SYSTEM W(sUser,te(APXLOG_MARKat use thcFMARKa
    Ie(APXLOGs=oResult  DYNLOAT    &lpPToces               __apxProce2;
    lpProc = APXHASD  i, l =aP>T
    apxFree(lpPthcFMARKa
    Ie(APXLOGs=oResult  DYNLOAT    &lpPToces               __apxProce2;
    lpProc = A
   STAM l =oResult;
otrlcpyW(sUser, SIZ_RESLEN,)_RESLEN, DEFA   DYNLOAD_FPTR_DECLARE(Exit    }

    if (EN, STAT_SYSTEM W(sUser,te(AlpProc->szWorkinser, SIZ_ser, S 